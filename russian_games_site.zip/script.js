function checkAnswer(id, correct) {
  let selected = document.querySelector(`input[name=${id}]:checked`);
  if (!selected) { alert("Выберите ответ!"); return; }
  if (selected.value === correct) {
    alert("Правильно!");
  } else {
    alert("Неправильно. Попробуйте снова.");
  }
}